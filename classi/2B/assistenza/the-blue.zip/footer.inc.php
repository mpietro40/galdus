<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
    <div id="footers">
      	<div class="footerleft"> 
		<ul><?php get_navigation(return_page_slug()); ?></ul>
      	</div>
	<div class="footerright">
      		<?php get_footer(); ?>
        	<?php echo date('Y'); ?><a href="<?php get_site_url(); ?>" >
        	<?php get_site_name(); ?></a> :: <?php get_site_credits(); ?>
		<div class="social">
		<a href="https://twitter.com" title="Twitter">t </a>
		<a href="http://facebook.com" title="Facebook">f </a>
		<a href="http://google.com" title="Google">g</a>
		</div>
	</div>
</div> 
</body>
</html>