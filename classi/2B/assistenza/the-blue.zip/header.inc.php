<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
<!DOCTYPE html>
<html> 
	<head>  
		<?php get_header(); ?>	
		<meta name="robots" content="index, follow" />
		<meta name="Generator" content="GetSimple" />
		<meta name="Keywords" content="GetSimple" />
		<meta name="Description" content="GetSimple - blue theme" />
		<meta http-equiv="pragma" content="no-cache" />
		<meta http-equiv="cache-control" content="no-cache" />
	    <link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/style.css" media="all" />
		<link rel="shortcut icon" href="<?php get_theme_url(); ?>/favicon.ico">
		<!--[if gte IE 9]> 
        <style type="text/css"> 
        .gradient { 
        filter: none; 
        } 
        </style> 
        <![endif]-->
	<title>
		<?php get_page_clean_title(); ?> :: <?php get_site_name(); ?>
	</title> 
	</head>   
<body id="<?php get_page_slug(); ?>" >         
	<div class="container">           
	<div id="logo"><!-- logo - If U want, change logo.png in images folder -->        
        <?php get_site_name(); ?></div>
	<div id="menu">           
		<ul><?php get_navigation(return_page_slug()); ?></ul>
        <div class="clear"></div>             
	</div> 