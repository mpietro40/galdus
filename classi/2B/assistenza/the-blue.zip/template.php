<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
include('header.inc.php');?>
	<div id="main">            
        <div class="contentleft">
		<div class="contentpadding">
		<h1><?php get_page_title(); ?></h1>                					     
                <?php get_page_content(); ?>
		</div>
	</div>
        <div class="sidebar">
		<div class="section">
		<?php get_component('sidebar');	?>
		</div>  
        </div>
		<div class="clear"></div>         
	</div>	
<?php include('footer.inc.php'); ?>

